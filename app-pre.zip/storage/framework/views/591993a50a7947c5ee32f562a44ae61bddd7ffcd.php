<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta content="marvel expo, Marvel Expo, marvelexpo, MARVEL EXPO, marvel expo 2022, Marvel Expo 2022, Marvel Expo Ticket, marvel expo ticket, marvel expo 2022 ticket, Marvel Expo Ticket 2022" name="keywords">
    <title>Marvel Expo 2022</title>
    <link rel="stylesheet" href="css/app.css">
</head>

<body>
    <div class="wrapper run-animation" id="animate">
        <div class="logo">

            <span class="marvel">Marvel Expo</span>
            <span class="studios">2022</span>
            <br/>

            <a href="/buy"><button class="restart">Buy Ticket</button></a>
        </div>
    </div>

    <div class="images"></div>

</body>

</html>
<?php /**PATH C:\Users\hp\OneDrive\Desktop\expo\marvel\resources\views/index.blade.php ENDPATH**/ ?>