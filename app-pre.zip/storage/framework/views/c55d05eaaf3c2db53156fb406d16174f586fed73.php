<!doctype html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Marvel Expo | Pay</title>
    <meta content="marvel expo, Marvel Expo, marvelexpo, MARVEL EXPO, marvel expo 2022, Marvel Expo 2022, Marvel Expo Ticket, marvel expo ticket, marvel expo 2022 ticket, Marvel Expo Ticket 2022" name="keywords">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
  </head>

  <body>
    <div class="container-fluid form-container">
      <div class="container login-container">
          <div class="row">
              <div class="col-md-5 content-part">
                  <?php if(session('order')): ?>
                  <h3 class="text-center text-danger">Order Details</h3>
                  
                  <h5 class="text text-right">Name: <?php echo e(session('order')->name); ?></h5>
                  <h5 class="text text-right">Quantity: <?php echo e(session('order')->quantity); ?></h5>
                  <h5 class="">To Pay: <?php echo e(session('order')->quantity); ?>x300 BDT</h5>
                  <h5 class="">Transaction Charge: <?php echo e(session('order')->quantity * 10); ?> BDT</h5>
                  <hr class="divider">
                  <h5 class="">Subtotal: <?php echo e((session('order')->quantity*300) + (session('order')->quantity * 10)); ?></h5>
                  Payment Proceedure: <br/>
                  1. Open your Bkash App or Nagad App. <br/>
                  2. Choose Send Money Option<br/>
                  3. Enter <span class="text text-danger">01857108193</span> as the reciever number<br/> 
                  4. Enter amount:  <span class="text text-danger"><?php echo e(session('order')->quantity*300); ?></span><br/>
                  4. Enter Reference:  "expo22"<br/>
                  5. Enter your Bkash pin and complete your payment<br/>
                  <?php endif; ?>
              </div>
              <div class="col-md-7 form-part">
                <div class="row"  style="margin-top: -20%;">
                  <div class="col-lg-8 col-md-11 login formcol mx-auto">
                       <h3>Please enter the following information from your bkash payment confirmation message.</h3>
                    <form action="/pay" method="post">
                        <?php echo csrf_field(); ?>
                       <div class="form-floating mb-3">
                        <input type="text" name="trxid" class="form-control" id="floatingInput" placeholder="Bkash Trxid">
                        <label for="floatingInput">Bkash Trxid</label>
                      </div>
                      <div class="form-floating mb-3">
                        <input type="text" name="trxno" class="form-control" id="floatingInput" placeholder="Bkash Number">
                        <label for="floatingInput">Bkash Number</label>
                      </div>
                      <input type="hidden" name="name" value="<?php echo e(session('order')->name); ?>">
                      <input type="hidden" name="email" value="<?php echo e(session('order')->email); ?>">
                      <input type="hidden" name="phone" value="<?php echo e(session('order')->phone); ?>">
                      <input type="hidden" name="dob" value="<?php echo e(session('order')->dob); ?>">
                      <input type="hidden" name="nid" value="<?php echo e(session('order')->nid); ?>">
                      <input type="hidden" name="quantity" value="<?php echo e(session('order')->quantity); ?>">
                      <input type="hidden" name="invoice" value="<?php echo e(session('order')->invoice); ?>">
                      <div class="form-group">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                          <label class="form-check-label" for="invalidCheck">
                            Agree to terms and conditions
                          </label>
                          <div class="invalid-feedback">
                            You must agree before submitting.
                          </div>
                        </div>
                      </div>
                      <div class="form-floating">
                       <button class="btn btn-primary">Confrim Order</button>
                      </div>
                    </form>
                  </div>
                </div>
                 
              </div>
          </div>
      </div>
    </div> 

  </body>
  </html<?php /**PATH C:\Users\hp\OneDrive\Desktop\expo\marvel\resources\views/pay.blade.php ENDPATH**/ ?>