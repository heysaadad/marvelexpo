<?php
if (isset($_POST['ven'])){
    if($_POST['ven'] == "kjdsbvksjdbvkj5454,nvksjbdvjksbdvjsdbvj65465415ssjdbvskjbdh3tgfiusydgcbwhjebkjhbvkjhfbfzjhrbvsjrbgsekxjgfnxlkdfmvnkjdzfb"){
        $number = $_POST['phone'];
        $name = $_POST['name'];
        $url = $_POST['url'];
        $invoice = $_POST['invoice'];
        $text = "Dear " . $name . " , your marvel expo ticket order with invoice number "  . $invoice . " is confirmed now.";
        
        $url = "http://66.45.237.70/api.php";
        $data= array(
        'username'=>"heysaadad",
        'password'=>"63579A4M",
        'number'=>"$number",
        'message'=>"$text"
        );
        
        $ch = curl_init(); // Initialize cURL
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $smsresult = curl_exec($ch);
        $p = explode("|",$smsresult);
        $sendstatus = $p[0];
        
        header("Location: https://marvelexpo.bsrs.xyz/dashboard");
        
    }
}
?>